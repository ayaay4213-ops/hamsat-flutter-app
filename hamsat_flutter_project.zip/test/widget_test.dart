import 'package:flutter_test/flutter_test.dart';
import 'package:hamsat/main.dart';

void main() {
  testWidgets('shows Hamsat registration screen', (tester) async {
    await tester.pumpWidget(const HamsatApp());
    expect(find.text('همسات'), findsOneWidget);
    expect(find.text('إنشاء حساب تجريبي'), findsOneWidget);
  });
}
