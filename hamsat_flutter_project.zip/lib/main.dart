import 'package:flutter/material.dart';

void main() {
  runApp(const HamsatApp());
}

const Color gold = Color(0xFFD8A832);
const Color darkGold = Color(0xFF8F6410);
const Color cream = Color(0xFFFFF7DA);
const Color pageColor = Color(0xFFFFFEFA);
const Color softGold = Color(0xFFFFE9A6);

class HamsatApp extends StatelessWidget {
  const HamsatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'همسات',
      theme: ThemeData(
        scaffoldBackgroundColor: pageColor,
        colorScheme: ColorScheme.fromSeed(seedColor: gold),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(
          backgroundColor: softGold,
          foregroundColor: darkGold,
          centerTitle: false,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFEBDDAF)),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: Color(0xFFEBDDAF)),
          ),
        ),
      ),
      home: const MainPage(),
    );
  }
}

class DemoUser {
  final String name;
  final String email;
  final String id;
  const DemoUser({required this.name, required this.email, required this.id});
}

class AppSession extends ChangeNotifier {
  DemoUser? user;
  final List<DemoUser> users = [];
  int _nextId = 11278965;

  bool get isLoggedIn => user != null;

  String? register(String name, String email, String password) {
    if (name.trim().isEmpty) return 'اكتبي الاسم أولًا.';
    if (!_validEmail(email)) return 'تحققي من البريد الإلكتروني.';
    if (password.length < 6) return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل.';
    if (users.any((u) => u.email.toLowerCase() == email.trim().toLowerCase())) {
      return 'هذا البريد مسجل في هذه النسخة التجريبية.';
    }
    final newUser = DemoUser(
      name: name.trim(),
      email: email.trim(),
      id: (_nextId++).toString(),
    );
    users.add(newUser);
    user = newUser;
    notifyListeners();
    return null;
  }

  String? login(String email, String password) {
    if (!_validEmail(email) || password.length < 6) {
      return 'أدخلي بريدًا صحيحًا وكلمة مرور من 6 أحرف على الأقل.';
    }
    final found = users.where(
      (u) => u.email.toLowerCase() == email.trim().toLowerCase(),
    );
    if (found.isEmpty) {
      return 'لا يوجد حساب تجريبي بهذا البريد. أنشئي حسابًا أولًا.';
    }
    user = found.first;
    notifyListeners();
    return null;
  }

  void logout() {
    user = null;
    notifyListeners();
  }

  bool _validEmail(String email) => email.contains('@') && email.contains('.');
}

final AppSession session = AppSession();

class MainPage extends StatefulWidget {
  const MainPage({super.key});
  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: session,
      builder: (context, _) {
        if (!session.isLoggedIn) {
          return const AuthPage();
        }
        final pages = [
          const HomePage(),
          const DiscoverPage(),
          const CreatePlaceholderPage(),
          const MessagesPage(),
          const ProfilePage(),
        ];
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            body: SafeArea(
              child: IndexedStack(index: selectedIndex, children: pages),
            ),
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: selectedIndex,
              onTap: (index) {
                if (index == 2) {
                  _showCreateOptions(context);
                } else {
                  setState(() => selectedIndex = index);
                }
              },
              type: BottomNavigationBarType.fixed,
              backgroundColor: softGold,
              selectedItemColor: darkGold,
              unselectedItemColor: const Color(0xFF987C3B),
              selectedFontSize: 11,
              unselectedFontSize: 10,
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'الرئيسية'),
                BottomNavigationBarItem(icon: Icon(Icons.explore_rounded), label: 'اكتشف'),
                BottomNavigationBarItem(icon: Icon(Icons.add_circle, size: 34), label: 'إنشاء'),
                BottomNavigationBarItem(icon: Icon(Icons.chat_bubble_rounded), label: 'الرسائل'),
                BottomNavigationBarItem(icon: Icon(Icons.person_rounded), label: 'حسابي'),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showCreateOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      builder: (sheetContext) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: Wrap(children: [
            const Padding(
              padding: EdgeInsets.all(18),
              child: Text('إنشاء', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            ),
            ListTile(
              leading: const Icon(Icons.mic, color: darkGold),
              title: const Text('إنشاء غرفة صوتية تجريبية'),
              onTap: () {
                Navigator.pop(sheetContext);
                Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomPage()));
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo, color: darkGold),
              title: const Text('نشر صورة أو منشور'),
              onTap: () {
                Navigator.pop(sheetContext);
                _message(context, 'نشر الصور والمنشورات سيضاف في مرحلة لاحقة.');
              },
            ),
          ]),
        ),
      ),
    );
  }
}

void _message(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
}

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final name = TextEditingController();
  final email = TextEditingController();
  final password = TextEditingController();
  bool registering = true;
  bool hidePassword = true;

  @override
  void dispose() {
    name.dispose();
    email.dispose();
    password.dispose();
    super.dispose();
  }

  void submit() {
    final error = registering
        ? session.register(name.text, email.text, password.text)
        : session.login(email.text, password.text);
    if (error != null) _message(context, error);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: Column(
                  children: [
                    Container(
                      width: 92,
                      height: 92,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(colors: [Color(0xFFFFEBA0), Color(0xFFD6A42D)]),
                        borderRadius: BorderRadius.circular(28),
                        boxShadow: const [BoxShadow(color: Color(0x22A67C16), blurRadius: 18, offset: Offset(0, 8))],
                      ),
                      child: const Icon(Icons.auto_awesome, color: darkGold, size: 50),
                    ),
                    const SizedBox(height: 18),
                    const Text('همسات', style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: darkGold)),
                    const SizedBox(height: 7),
                    const Text('مساحتك للحديث والأصدقاء', style: TextStyle(color: Color(0xFF8F6410))),
                    const SizedBox(height: 30),
                    if (registering) ...[
                      TextField(controller: name, textInputAction: TextInputAction.next, decoration: const InputDecoration(labelText: 'الاسم الظاهر', prefixIcon: Icon(Icons.person_outline))),
                      const SizedBox(height: 13),
                    ],
                    TextField(
                      controller: email,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined)),
                    ),
                    const SizedBox(height: 13),
                    TextField(
                      controller: password,
                      obscureText: hidePassword,
                      onSubmitted: (_) => submit(),
                      decoration: InputDecoration(
                        labelText: 'كلمة المرور (6 أحرف على الأقل)',
                        prefixIcon: const Icon(Icons.lock_outline),
                        suffixIcon: IconButton(
                          onPressed: () => setState(() => hidePassword = !hidePassword),
                          icon: Icon(hidePassword ? Icons.visibility : Icons.visibility_off),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: FilledButton(
                        style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.white),
                        onPressed: submit,
                        child: Text(registering ? 'إنشاء حساب تجريبي' : 'تسجيل الدخول', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(() => registering = !registering),
                      child: Text(
                        registering ? 'لديك حساب تجريبي؟ تسجيل الدخول' : 'مستخدم جديد؟ إنشاء حساب',
                        style: const TextStyle(color: darkGold),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'نسخة تجريبية: الحسابات مؤقتة وتُحذف عند إغلاق التطبيق.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: Colors.black54),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GoldHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const GoldHeader({super.key, required this.title, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 15),
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xFFFFF0B5), Color(0xFFE5BD56)]),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(18)),
      ),
      child: Row(children: [
        const Icon(Icons.auto_awesome, color: darkGold),
        const SizedBox(width: 8),
        Text(title, style: const TextStyle(color: darkGold, fontSize: 19, fontWeight: FontWeight.bold)),
        const Spacer(),
        trailing ?? const Icon(Icons.notifications_none, color: darkGold),
      ]),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const GoldHeader(title: 'همسات'),
      Expanded(child: ListView(padding: const EdgeInsets.all(12), children: [
        const GoldBanner(title: 'مرحبًا بك في همسات', subtitle: 'اكتشف الأصدقاء والغرف الصوتية', icon: Icons.mic, height: 112),
        const SizedBox(height: 14),
        const SectionTitle(title: 'مميزات همسات'),
        const Row(children: [
          Expanded(child: FeatureCard(title: 'غرف صوتية', icon: Icons.headphones, color: Color(0xFF9D7120))),
          SizedBox(width: 8),
          Expanded(child: FeatureCard(title: 'هدايا مميزة', icon: Icons.card_giftcard, color: Color(0xFFB24D39))),
          SizedBox(width: 8),
          Expanded(child: FeatureCard(title: 'مستويات VIP', icon: Icons.workspace_premium, color: Color(0xFF337950))),
        ]),
        const SizedBox(height: 17),
        const SectionTitle(title: 'غرف مقترحة'),
        RoomTile(title: 'سوالف المساء', subtitle: 'أحاديث وأجواء جميلة', people: 'غرفة تجريبية', icon: Icons.nightlight_round, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomPage(roomName: 'سوالف المساء')))),
        RoomTile(title: 'أصدقاء همسات', subtitle: 'تعرف على أصدقاء جدد', people: 'غرفة تجريبية', icon: Icons.people, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomPage(roomName: 'أصدقاء همسات')))),
        RoomTile(title: 'عالم الموسيقى', subtitle: 'استمع وشاركنا الحديث', people: 'غرفة تجريبية', icon: Icons.music_note, onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RoomPage(roomName: 'عالم الموسيقى')))),
        const SizedBox(height: 14),
        const GoldBanner(title: 'انضم إلى مجتمع همسات', subtitle: 'ابدأ محادثة جديدة اليوم', icon: Icons.forum, height: 90),
      ])),
    ]);
  }
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});
  @override
  Widget build(BuildContext context) {
    final categories = [
      ('العائلة', Icons.family_restroom, '1706'),
      ('نجوم همسات', Icons.star, '5046'),
      ('الألعاب', Icons.sports_esports, '1394'),
      ('CP Life', Icons.favorite, '2269'),
      ('دردشة عربية', Icons.chat, '2380'),
      ('موسيقى', Icons.music_note, '980'),
    ];
    return Column(children: [
      const GoldHeader(title: 'اكتشف'),
      Expanded(child: ListView(padding: const EdgeInsets.all(14), children: [
        const SectionTitle(title: 'مواضيع مميزة'),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: categories.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 2.0, crossAxisSpacing: 10, mainAxisSpacing: 10),
          itemBuilder: (context, index) {
            final item = categories[index];
            return InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () => _message(context, 'تم اختيار ${item.$1}'),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Colors.white, border: Border.all(color: const Color(0xFFEBDDAF)), borderRadius: BorderRadius.circular(12)),
                child: Row(children: [
                  CircleAvatar(backgroundColor: cream, child: Icon(item.$2, color: darkGold)),
                  const SizedBox(width: 8),
                  Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(item.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
                    Text('${item.$3} مهتمًا', style: const TextStyle(color: Colors.black54, fontSize: 11)),
                  ])),
                ]),
              ),
            );
          },
        ),
        const SizedBox(height: 20),
        const SectionTitle(title: 'منشورات المجتمع'),
        const PostCard(name: 'طارق', text: 'من معنا اليوم؟ شاركونا الحديث ✨', icon: Icons.person),
        const PostCard(name: 'نجمة همسات', text: 'أجمل الأوقات تبدأ مع الأصدقاء 💛', icon: Icons.face),
      ])),
    ]);
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    final user = session.user!;
    return Column(children: [
      GoldHeader(title: 'حسابي', trailing: IconButton(icon: const Icon(Icons.logout, color: darkGold), tooltip: 'تسجيل الخروج', onPressed: () => session.logout())),
      Expanded(child: ListView(children: [
        Container(
          padding: const EdgeInsets.symmetric(vertical: 24),
          color: const Color(0xFFFFF9E9),
          child: Column(children: [
            const CircleAvatar(radius: 43, backgroundColor: gold, child: Icon(Icons.person, size: 48, color: Colors.white)),
            const SizedBox(height: 9),
            Text(user.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            Text(user.email, style: const TextStyle(color: Colors.black54, fontSize: 12)),
            Text('معرّف المستخدم: ${user.id}', style: const TextStyle(color: Colors.black54, fontSize: 12)),
            const SizedBox(height: 18),
            const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              StatItem(number: '0', label: 'متابعون'),
              StatItem(number: '0', label: 'متابعة'),
              StatItem(number: '0', label: 'أصدقاء'),
            ]),
          ]),
        ),
        Padding(padding: const EdgeInsets.all(12), child: Column(children: [
          const GoldBanner(title: 'محفظتي', subtitle: 'ستضاف عند تفعيل نظام العملات', icon: Icons.account_balance_wallet, height: 82),
          const SizedBox(height: 10),
          const Row(children: [
            Expanded(child: FeatureCard(title: 'المستوى LV.0', icon: Icons.shield, color: Color(0xFF76519C))),
            SizedBox(width: 8),
            Expanded(child: FeatureCard(title: 'VIP 0', icon: Icons.workspace_premium, color: Color(0xFF319060))),
          ]),
          const SizedBox(height: 12),
          const ProfileOption(icon: Icons.card_giftcard, title: 'هداياي'),
          const ProfileOption(icon: Icons.face, title: 'مركز التخصيص'),
          const ProfileOption(icon: Icons.store, title: 'المتجر'),
          const ProfileOption(icon: Icons.star, title: 'أدوات'),
          const ProfileOption(icon: Icons.home, title: 'عائلتي'),
          const ProfileOption(icon: Icons.settings, title: 'الإعدادات'),
        ])),
      ])),
    ]);
  }
}

class MessagesPage extends StatelessWidget {
  const MessagesPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const GoldHeader(title: 'الرسائل'),
      const Expanded(child: Center(child: Padding(
        padding: EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.mark_chat_unread, size: 60, color: gold),
          SizedBox(height: 12),
          Text('لا توجد رسائل حتى الآن', style: TextStyle(fontSize: 17, color: darkGold)),
          SizedBox(height: 6),
          Text('ستتم إضافة المحادثات الخاصة في مرحلة لاحقة', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
        ]),
      ))),
    ]);
  }
}

class CreatePlaceholderPage extends StatelessWidget {
  const CreatePlaceholderPage({super.key});
  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}

class RoomPage extends StatefulWidget {
  final String roomName;
  const RoomPage({super.key, this.roomName = 'غرفة همسات التجريبية'});
  @override
  State<RoomPage> createState() => _RoomPageState();
}

class _RoomPageState extends State<RoomPage> {
  bool muted = true;
  bool joined = false;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(widget.roomName), backgroundColor: softGold, foregroundColor: darkGold),
        body: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(children: [
            const SizedBox(height: 18),
            Container(
              width: 100, height: 100,
              decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFFFEBA0), Color(0xFFD6A42D)])),
              child: const Icon(Icons.mic, size: 52, color: darkGold),
            ),
            const SizedBox(height: 14),
            Text(widget.roomName, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold, color: darkGold)),
            const SizedBox(height: 6),
            const Text('معاينة محلية — الصوت المباشر غير مفعّل', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 26),
            const Wrap(spacing: 14, runSpacing: 14, alignment: WrapAlignment.center, children: [
              RoomSeat(name: 'المضيف', icon: Icons.workspace_premium),
              RoomSeat(name: 'مقعد 2', icon: Icons.person),
              RoomSeat(name: 'مقعد 3', icon: Icons.person_outline),
              RoomSeat(name: 'مقعد 4', icon: Icons.person_outline),
              RoomSeat(name: 'مقعد 5', icon: Icons.person_outline),
              RoomSeat(name: 'مقعد 6', icon: Icons.person_outline),
            ]),
            const Spacer(),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: cream, borderRadius: BorderRadius.circular(16)),
              child: const Row(children: [
                Icon(Icons.info_outline, color: darkGold),
                SizedBox(width: 8),
                Expanded(child: Text('هذه نسخة واجهة تجريبية. لا يُرسل صوت أو بيانات إلى مستخدمين آخرين.')),
              ]),
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: OutlinedButton.icon(
                onPressed: () => setState(() { joined = !joined; muted = !joined; }),
                icon: Icon(joined ? Icons.logout : Icons.headphones),
                label: Text(joined ? 'مغادرة المعاينة' : 'دخول المعاينة'),
              )),
              const SizedBox(width: 10),
              Expanded(child: FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.white),
                onPressed: joined ? () => setState(() => muted = !muted) : null,
                icon: Icon(muted ? Icons.mic_off : Icons.mic),
                label: Text(muted ? 'الميكروفون مغلق' : 'كتم الميكروفون'),
              )),
            ]),
          ]),
        ),
      ),
    );
  }
}

class RoomSeat extends StatelessWidget {
  final String name;
  final IconData icon;
  const RoomSeat({super.key, required this.name, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(width: 88, child: Column(children: [
    CircleAvatar(radius: 30, backgroundColor: cream, child: Icon(icon, color: darkGold, size: 30)),
    const SizedBox(height: 6),
    Text(name, style: const TextStyle(fontSize: 12)),
  ]));
}

class GoldBanner extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final double height;
  const GoldBanner({super.key, required this.title, required this.subtitle, required this.icon, required this.height});
  @override
  Widget build(BuildContext context) => Container(
    height: height, padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), gradient: const LinearGradient(colors: [Color(0xFFFFEBA0), Color(0xFFD6A42D)])),
    child: Row(children: [
      Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Color(0xFF704B08), fontWeight: FontWeight.bold, fontSize: 17)),
        const SizedBox(height: 5),
        Text(subtitle, style: const TextStyle(color: Color(0xFF704B08), fontSize: 12)),
      ])),
      Icon(icon, size: 43, color: const Color(0xFF9D7017)),
    ]),
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: Text(title, style: const TextStyle(color: darkGold, fontSize: 17, fontWeight: FontWeight.bold)),
  );
}

class FeatureCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  const FeatureCard({super.key, required this.title, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) => Container(
    height: 78,
    decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12), border: Border.all(color: gold.withOpacity(0.6))),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: Colors.white, size: 28),
      const SizedBox(height: 4),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
    ]),
  );
}

class RoomTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String people;
  final IconData icon;
  final VoidCallback onTap;
  const RoomTile({super.key, required this.title, required this.subtitle, required this.people, required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, elevation: 1, margin: const EdgeInsets.only(bottom: 9),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12), side: const BorderSide(color: Color(0xFFEDE2C2))),
    child: ListTile(
      leading: CircleAvatar(backgroundColor: cream, child: Icon(icon, color: darkGold)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle),
      trailing: Text(people, style: const TextStyle(color: darkGold, fontSize: 11)),
      onTap: onTap,
    ),
  );
}

class PostCard extends StatelessWidget {
  final String name;
  final String text;
  final IconData icon;
  const PostCard({super.key, required this.name, required this.text, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, margin: const EdgeInsets.only(bottom: 10),
    child: Padding(padding: const EdgeInsets.all(13), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        CircleAvatar(backgroundColor: cream, child: Icon(icon, color: darkGold)),
        const SizedBox(width: 9),
        Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
      ]),
      const SizedBox(height: 12),
      Text(text),
      const SizedBox(height: 12),
      const Row(children: [
        Icon(Icons.favorite_border, color: Colors.redAccent, size: 19),
        SizedBox(width: 5),
        Text('إعجاب'),
        SizedBox(width: 18),
        Icon(Icons.chat_bubble_outline, color: darkGold, size: 19),
        SizedBox(width: 5),
        Text('تعليق'),
      ]),
    ])),
  );
}

class StatItem extends StatelessWidget {
  final String number;
  final String label;
  const StatItem({super.key, required this.number, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(number, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
    const SizedBox(height: 4),
    Text(label, style: const TextStyle(color: Colors.black54, fontSize: 11)),
  ]);
}

class ProfileOption extends StatelessWidget {
  final IconData icon;
  final String title;
  const ProfileOption({super.key, required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => ListTile(
    dense: true,
    leading: Icon(icon, color: darkGold),
    title: Text(title, style: const TextStyle(fontSize: 14)),
    trailing: const Icon(Icons.arrow_back_ios, size: 15, color: Colors.black38),
    onTap: () => _message(context, '$title — ستضاف في مرحلة لاحقة'),
  );
}
